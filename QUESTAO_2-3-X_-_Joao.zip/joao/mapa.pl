% Banco de dados de adjacencias.
% A.
adj_(a,b).
adj_(a,c).
adj_(a,d).
% B.
adj_(b,c).
adj_(b,d).
adj_(b,e).
% C.
adj_(c,d).
% D.
adj_(e,d).
% Metodos de definicao.
% X e adj a Y como Y e adj a X.
adj(X,Y):- adj_(Y,X).
adj(X,Y):- adj_(X,Y).

% Questao 1.3.
% Adicionando COR.
cor(a,verde).
% cor(b,azul).
cor(b,amarelo).
cor(c,vermelho).
cor(d,amarelo).
cor(e,vermelho).

% verifica conflito.
% esta em conflito quando a cor de X for igual a cor de Y e forem adjac.
conflito:-cor(_x,P),cor(_y,P),adj(_x,_y).
%conflito utilizando 2 parametros.
conflito2(X,Y):-cor(X,P),cor(Y,P),adj(X,Y).
