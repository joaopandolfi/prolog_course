% Banco de dados Controle de Tr�fego.

% == PARTIDAS ==
% Voo ida [voo, destino, hora prevista, hora real].
vooid(tp123,lisboa,1430,1430).
vooid(ni234,manchester,1525,1600).
vooid(tp876,faro,1418,1430).
vooid(ni498,madrid,1500,1500).

% == CHEGADAS ==
%voo volta [voo, origem, hora prevista, hora real].
voovo(tp123,lisboa,1400,1435).
voovo(ni533,funchal,1500,1500).
voovo(tp877,santiago,1430,1500).
voovo(ni498,manchester,1600,1550).

% == Procedimentos ==

%parteAHoras [voo] -- 3.2-(a)
parteAHoras(X):- vooid(X,_,_b,_b).

%vaivem [voo] -- 3.2-(b)
vaivem(X):-vooid(X,_a,_,_),voovo(X,_a,_,_).

%ligacao [cidade saida, cidade chegada] -- 3.2-(c)
ligacao(X,Y):- vooid(_a,X,_,_),voovo(_a,Y,_,_),not(X == Y).

%chegaAtrasado [hora real chegada] -- 3.2-(d)
chegaAtrasado(X):- voovo(X,_,_a,_b),_b>_a.

%emConflito [voo] -- 3.2-(e)
emConflito(X):- vooid(X,_,_,_a),voovo(X,_,_,_b),_a>_b.
















