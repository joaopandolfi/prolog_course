% ================= ATIVIDADE 2.X ====================.
%
% filho(A,B) :- A �e filho de B.
filho(jose,francisco).
filho(ana,francisco).
filho(madalena,francisco).
filho(francisco,domingos).
filho(rui,abilio).
filho(antonio,abilio).
filho(abilio,domingos).
filho(augusto,manuel).

% predicado pai -- Questao 2.3.
% X e pai de Y quando [Y e filho de X].
pai(X,Y):-filho(Y,X).
% predicado tio -- Tio 2.4.
% para ser tio tem que ser irmao do pai [X tio de Y].
% pego o pai do Y (irmao) pega o pai do irmao - verifica o pai de X.
tio(X,Y):-pai(I,Y),pai(I,P),pai(P,X).

% predicado primo -- Primo 2.5.
% [X e primo de Y].
primo(X,Y):- pai(A,X),pai(B,Y),pai(A2,A),pai(B2,B),A2==B2,not(X==Y).

% predicado Avo -- Avo 2.6.
% A avo de N.
avo(A,N):- pai(A,F),pai(F,N).

% Predicado Descendente -- Desc1 e Desc2 -- 2.7.
% Definindo descendente com recursividade.
% [X e descendente de Y].
desc(X,Y):- filho(X,Y).
desc(X,Y):- filho(X,T),desc(T,Y).











