%contatos.pl -- EXERCICIO 3.3-X
% telefone(P, T) :-
% o n. de telefone da casa da pessoa P �e T.
telefone(ana, 123).
telefone(ze, 234).
telefone(rui, 345).
telefone(pedro, 456).
telefone(marta, 567).
telefone(olga, 678).
% visita(X, Y) :-
% a pessoa X est�a de visita a pessoa Y.
visita(olga, ana).
visita(marta, ze).
visita(rui, olga).
visita(pedro, olga).
% emCasa(X) :- X est�a em casa.
emCasa(ze).
emCasa(ana).
%acompanhada [pessoa] -- 1.3.
acompanhada(X):- visita(_,X),emCasa(X).
%inconsistente -- 1.4.
inconsistente:- visita(X,_),emCasa(X).
%em_casa_de [P esta na casa de Q] -- 1.5.
em_casa_de(P,Q):-visita(P,Q).
em_casa_de(P,Q):-visita(P,Y),em_casa_de(Y,Q).
%contacto [P telefone Q] -- 1.6.
contacto(P,Q):- em_casa_de(P,_a),telefone(_a,Q).
%a_dar_festa [p pessoa a dar festa] -- 1.7.
a_dar_festa(B):- em_casa_de(_a,B),em_casa_de(_b,B),em_casa_de(_c,B),not(_a==_b),not(_a==_c),not(_b==_c).
