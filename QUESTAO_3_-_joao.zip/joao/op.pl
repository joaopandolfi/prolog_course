$op.pl -- EXERCICIO 3.3.X
%operadores.
% == DECLARA��O DE OPERADORES ==.
:-op(705, xfx, equiv).
:-op(704, xfy, impl).
:-op(703, xfy, ou).
:-op(702, xfy, e).
:-op(701, fx, nao).

% == PROVA ==.
prova(sim).
prova(nao X) :- disprova(X).
prova(X e Y) :- prova(X),prova(Y).
prova(X ou _):- prova(X).
prova(_ ou Y):- prova(Y).
prova(X impl _):- disprova(X).
prova(X impl Y):- prova(X), prova(Y).
prova(X equiv Y):- prova(X),prova(Y).
prova(X equiv Y):- disprova(X),disprova(Y).

% ==DISPROVA ==.
disprova(nao).
disprova(nao X)	:- prova(X).
disprova(X e _) :- disprova(X).
disprova(_ e Y) :- disprova(Y).
disprova(X ou Y):- disprova(X),disprova(Y).
disprova(X impl Y):- prova(X),disprova(Y).
disprova(X equiv Y):- disprova(X),prova(Y).
disprova(X equiv Y):- prova(X),disprova(Y).
