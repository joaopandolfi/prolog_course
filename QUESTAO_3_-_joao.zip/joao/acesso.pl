$acesso.pl -- EXERCICIO 3.3.X
%liga��es Diretas entre cidades.
%[origem,destino,transporte].
%== LISBOA ==.
ligacaodireta(lisboa,porto,auto).
ligacaodireta(lisboa,porto,cp).
ligacaodireta(lisboa,porto,aero).
%== PORTO ==.
ligacaodireta(porto,guimaraes,auto).
ligacaodireta(porto,braga,auto).
ligacaodireta(porto,braga,cp).
%== BRAGA ==.
ligacaodireta(braga,barcelos,auto).
ligacaodireta(braga,guimaraes,auto).

% ==== PREDICADOS ====.
%ha_ligacao [cidade A liga ha B] -- 2.1-(b)-i.
%ha_ligacao(A,B):-ligacaodireta(A,B,_).
%ha_ligacao(A,B):-ligacaodireta(A,_a,_),ligacaodireta(_a,B,_).

%ha_ligacao [cidade A liga ha B atravez de C] -- 2.1-(b)-ii.
%ha_ligacao(A,B,C):-ligacaodireta(A,B,C).
%ha_ligacao(A,B,C):-ligacaodireta(A,_a,C),ligacaodireta(_a,B,C).



%nao_engarrafado [ cidade , tipo ] -- 2.3.
%exemplo para teste
nao_engarrafado(porto,aero).
%ha_ligacao [cidade A liga ha B atravez de C].
ha_ligacao(A,B,C):-ligacaodireta(A,B,C),nao_engarrafado(B,C).
ha_ligacao(A,B,C):-ligacaodireta(A,_a,C),nao_engarrafado(B,C),ligacaodireta(_a,B,C).









