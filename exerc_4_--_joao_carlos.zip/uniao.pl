%exercicio 4.3.2
%Nome:
%Data:

%exercicio 1.
% Fatorial (a,b) fat de a � b.
fat(N,F) :- N=<0, F is 1.
fat(N,F) :- N1 is N-1, fat(N1,F1), F is N*F1.

%exercicio 2.
% Mult Nat  (A,B,C) a*b=c.
multn(_,B,C) :- B =< 0, C is 0.
multn(A,_,C) :- A =< 0, C is 0.
multn(A,B,C) :-	B1 is B-1,multn(A,B1,C1),C is A + C1.

%exercicio 3.
% Div Nat  (A,B,C) a/b=c.
divn(A,B,C) :- A < B, C is 0.
divn(A,B,C) :-	A1 is A-B ,divn(A1,B,C1),C is C1 +1.

%exercicio 4.
% Rest Div  (A,B,C) a/b resto = c.
divr(A,B,C) :- A < B, C is A.
divr(A,B,C) :-	A1 is A-B ,divr(A1,B,_c), C is _c.

%exercicio 5.
% Fibonnaci Fib na pos A � B.
fib(0,0).
fib(1,1).
fib(A,B) :- A > 1,
	A2 is A - 2,
	fib(A2,B2),
	A1 is A - 1,
	fib(A1,B1),
	B is B1 + B2.

%erxercicio 6.
% ackerman de A em B result C.
man(0,B,C) :- C is B + 1.
man(A,0,C) :- A>0 , A1 is A -1 , man(A1,1,C).
man(A,B,C) :- A>0 , B>0 ,
	A1 is A-1,
	B1 is B-1,
	man(A,B1,C1),
	man(A1,C1,C).
