%Questao 1.4.1.
aluno(joao,ppi).
aluno(pedro,ppi).
aluno(maria,ppiii).
aluno(rui,ppiii).
aluno(manuel,ppiii).
aluno(pedro,ppiii).
aluno(rui,ppiv).
%aluno(X,Y): X e aluno de Y
%Questao 1.4.2.
estuda(joao).
estuda(maria).
estuda(manuel).
fazappiii(X) :- aluno(X,ppiii).




