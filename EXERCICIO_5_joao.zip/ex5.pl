%EXERCICIO 5.
%NOME:
%DATA: 06/09/2013

%ultimo -- (X,Y) X e o ultimo de Y -- exerc 1.
ultimo(X,[X|Xs]) :- Xs = [].
ultimo(N,[_X|Xs]):- ultimo(N,Xs).

%Somatoria -- (X,Y) X e o somatorio de Y -- exerc 2.
somat([],0).
somat([X|Xs],N):- somat(Xs,N1), N is X + N1.

%adjacentes -- (X,Y,LIST) Y sao os adj de X na lista LIST -- exerc 3.
adj(Z,XL,[X|[X2|[X3|_Xs]]]) :- Z = X2,XL = [X,X3].
adj(N,Y,[_X|Xs]):- adj(N,Y,Xs).

%seleciona -- (X,Y,Z) X pertence a Y e o resto e Z -- exerc 4.
selec(Z,[X2|Xr],Xr) :- Z = X2 .
selec(N,[_X|Xs],Y) :- selec(N,Xs,Y).

%enesimo --  (X,Y,Z) X posicao de Z na lista Y -- exerc 5.
enem(X,[X1|_Xs],1) :- X = X1.
enem(X,[_X1|Xs],N) :- enem(X,Xs,N1),N is N1 +1.

%tamanho -- (X,Y) Y e o tamanho de X -- exerc6.
tamanho([],0).
tamanho([_X|Xs],N):- tamanho(Xs,N1), N is N1 +1.

%media -- M e a media da lista L -- exerc 7.
media(L,M) :- tamanho(L,T), somat(L,S), M is S/T.

%conta -- (X,Y,Z) X se repete Z vezes em Y -- exerc 8.
conta(_,[],0).
conta(Z,[X2|Xr],V) :- Z = X2, conta(Z,Xr,V1), V is V1 +1.
conta(N,[_X|Xs],Y) :- conta(N,Xs,Y).

%maximo -- (X,Y) X e o maior valor da lista Y --  exerc 9.
max(X,[X]).
max(X,[X2|Xs]) :-  max(X,Xs), X > X2.
max(X2,[X2|_]).

%posicao do max -- X e a posi��o do maximo na lista L -- exerc 10.
pmax(X,L) :- max(M,L),enem(M,L,X).




